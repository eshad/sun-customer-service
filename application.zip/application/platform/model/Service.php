<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2020/1/30
 * Time: 16:17
 */
namespace app\platform\model;

use think\Model;

class Service extends Model
{
    protected $table = 'wolive_service';
}