<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2020/3/11
 * Time: 16:24
 */
namespace app\platform\behavior;

use think\exception\HttpException;

class Cloud
{
    public function run(&$params)
    {

    }
}