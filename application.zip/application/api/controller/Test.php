<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2020/3/20
 * Time: 16:49
 */

namespace app\api\controller;

use app\admin\iplocation\Ip;

class Test
{
    public function index()
    {

    }
}